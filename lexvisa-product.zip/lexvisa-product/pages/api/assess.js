import OpenAI from "openai";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({ error: "OPENAI_API_KEY is not configured." });
  }

  const form = req.body;

  const prompt = `
You are LexVisa AI, an AI-assisted immigration workflow tool for UK Global Talent visa case preparation.

You are not a solicitor, immigration adviser, legal representative, or decision-maker.
You must not give final legal advice or say the applicant definitely qualifies.
Use cautious wording: "may be suitable", "appears relevant", "could support", "requires legal review".

Analyse the applicant information and produce structured workflow support.

Applicant data:
Nationality: ${form.nationality}
Current location: ${form.currentLocation}
Field: ${form.field}
Route preference: ${form.routePreference}
Professional experience: ${form.experience}
Current role: ${form.role}
Key achievements: ${form.achievements}
Awards/media/recognition: ${form.awards}
Publications/thought leadership: ${form.publications}
Leadership evidence: ${form.leadership}
Innovation evidence: ${form.innovation}
Commercial or sector impact: ${form.commercialImpact}
Evidence available: ${form.evidence}
Weaknesses/concerns: ${form.weaknesses}
Previous refusals/immigration concerns: ${form.previousRefusals}
Draft output requested: ${form.draftType}

Return the answer in this exact structure:

1. Initial Route Assessment
- Most relevant route
- Possible alternative routes
- Why this route may be relevant
- Why legal review is required

2. Global Talent Suitability Snapshot
- Potential field
- Exceptional Talent vs Exceptional Promise indication
- Strength level: Strong / Moderate / Weak
- Short explanation

3. Evidence Map
Use a table-style text section with:
- Evidence category
- Available evidence
- Strength
- Comments

4. Missing or Weak Evidence
List gaps and explain why they matter.

5. Risk Flags
List potential risks using cautious wording.

6. Recommended Evidence Checklist
Separate into:
- Essential
- Strongly recommended
- Optional but helpful

7. Draft Document Support
Provide draft structures, not final legal documents, for:
- Recommendation letter
- Client follow-up email
- Personal statement outline
- Evidence explanation note

8. Client Follow-up Questions
List practical questions to clarify the case.

9. Case Preparation Notes for Professional Review
Give concise notes for an immigration professional.

10. Disclaimer
State that this is AI-generated workflow support and not legal advice.
`;

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const completion = await client.chat.completions.create({
      model: "gpt-4.1-mini",
      messages: [
        { role: "system", content: "You are a careful legal workflow assistant. You do not provide legal advice." },
        { role: "user", content: prompt }
      ],
      temperature: 0.3
    });

    const analysis = completion.choices?.[0]?.message?.content || "No analysis generated.";
    return res.status(200).json({ analysis });
  } catch (error) {
    return res.status(500).json({ error: error.message || "AI analysis failed." });
  }
}
